package edu.byu.cs.tweeter.client.model.service.observer;

public interface DefaultObserver extends Observer {
    void handleSuccess();
}
