package edu.byu.cs.tweeter.client.model.service.observer;

public interface LogoutObserver extends DefaultObserver{
}
